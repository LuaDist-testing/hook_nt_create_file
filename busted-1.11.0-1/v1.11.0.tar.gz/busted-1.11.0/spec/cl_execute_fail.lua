-- supporting testfile; belongs to 'cl_spec.lua'


error("This compiles fine, but throws an error when being run")
