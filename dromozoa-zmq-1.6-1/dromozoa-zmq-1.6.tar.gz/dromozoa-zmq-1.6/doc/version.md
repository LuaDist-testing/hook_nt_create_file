System | Version | Name | URL
----|----|----|---
CentOS 6 (EPEL) | 3.2.5 | zeromq3-devel| https://dl.fedoraproject.org/pub/epel/6/x86_64/
CentOS 7 (EPEL) | 4.1.4 | zeromq-devel | https://dl.fedoraproject.org/pub/epel/7/x86_64/z/
Raspbian GNU/Linux 8 (jessie) | 4.0.5 | libzmq3-dev |
