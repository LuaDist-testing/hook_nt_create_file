System | Version | URL
----|----|----
CentOS 5 | 3.3.6 |
CentOS 6 | 3.6.20 | http://mirror.centos.org/centos/6/os/x86_64/Packages/
CentOS 7 | 3.7.17 | http://mirror.centos.org/centos/7/os/x86_64/Packages/
Amazon Linux AMI 2016.09 | 3.7.17 | https://aws.amazon.com/jp/amazon-linux-ami/2016.09-packages/
OS X 10.10.5 | 3.8.5 |
OS X 10.12.3 | 3.14.0 |
Raspbian GNU/Linux 8 (jessie) | 3.8.7 |

Function | Version
----|----
sqlite3_create_function_v2|3.7.3
sqlite3_close_v2|3.7.14
sqlite3_errstr|3.7.15
